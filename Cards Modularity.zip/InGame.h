#ifndef IN_GAME
#define IN_GAME
#include "Deck.h"

Winner OpenCard(Card Headplayer1 , Card Headplayer2);

void Add_Cards(Winner winner , Card* Head1 , Card* Head2 , Card* HeadPot1 , Card* HeadPot2);

#endif
